﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gui2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            step = 0;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        int step = 0;
        
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int x = pictureBox1.Location.X;
            int y = pictureBox1.Location.Y;

            //ylösalas
            if (e.KeyCode == Keys.NumPad8) y -= step; //Pohjoinen
            if (e.KeyCode == Keys.NumPad6) x += step; //itä
            if (e.KeyCode == Keys.NumPad2) y += step; //etelä
            if (e.KeyCode == Keys.NumPad4) x -= step; //länsi
            //lounaskaakkoyms
            if (e.KeyCode == Keys.NumPad9) x += step; //koilinen
            if (e.KeyCode == Keys.NumPad9) y -= step; //koilinen
            if (e.KeyCode == Keys.NumPad3) y += step; //kaakko
            if (e.KeyCode == Keys.NumPad3) x += step; //kaakko
            if (e.KeyCode == Keys.NumPad1) x -= step; //lounas
            if (e.KeyCode == Keys.NumPad1) y += step; //lounas
            if (e.KeyCode == Keys.NumPad7) x -= step; //luode
            if (e.KeyCode == Keys.NumPad7) y -= step; //luode

            pictureBox1.Location = new Point(x, y);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            step = 5;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
