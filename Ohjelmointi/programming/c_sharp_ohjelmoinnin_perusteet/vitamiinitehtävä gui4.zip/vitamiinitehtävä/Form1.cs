﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vitamiinitehtävä
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int koko;
        String[,] aineet =
            {{" A-vitamiini"," RE"," 900"," 700"},
            {" D-vitamiini"," µg"," 10-20"," 1 10/20"},
            {" E-vitamiini"," α-TE"," 10"," 8"},
            {" Tiamiini (B1-vitamiini)"," mg"," 1,3"," 1,0"},
            {" Riboflaviini, (B2-vitamiini)"," mg"," 1,5"," 1,3"},
            {" Niasiini"," NE"," 17"," 14"},
            {" B6-vitamiini"," mg"," 1,6"," 1,2"},
            {" Folaatti"," µg"," 300"," 300"},
            {" B12-vitamiini", "µg"," 2,0"," 2,0"},
            {" C-vitamiini"," mg"," 75"," 75"},
            {" Kalsium"," mg"," 800"," 800"},
            {" Fosfori"," mg"," 600"," 600"},
            {" Kalium"," g"," 3,5"," 3,1"},
            {" Magnesium"," mg", "350"," 350"},
            {" Rauta"," mg"," 9"," 9"},
            {" Sinkki"," mg"," 9"," 7"},
            {" Kupari"," mg"," 0,9"," 0,9"},
            {" Jodi"," µg"," 150"," 150"},
            {" Seleeni"," µg"," 60"," 50"}};

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            koko = aineet.Length / 4;
            for (int r = 0; r < koko; r++)
                comboBox1.Items.Add(aineet[r, 0]);
            comboBox1.Text = aineet[0, 0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sp = 1;
            if (radioButton2.Checked == true)
                sp = 2;
            String aine = (String)comboBox1.SelectedItem;
            String tarve = "not found";
            for (int r = 0; r < koko; r++)
                if (aineet[r, 0].Equals(aine))
                {
                    if (sp == 1)
                        tarve = aineet[r, 2] + " " + aineet[r, 1];
                    else
                        tarve = aineet[r, 3] + " " + aineet[r, 1];
                    break;
                }
            label1.Text = tarve;
        }
    }
}
