﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Palapeli
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        int xx;
        int yy;
        
        public Form1()
        {
            InitializeComponent();
            

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            int vasen = 1215;
            int pysty = 501;
            int x = rand.Next(vasen);
            int y = rand.Next(pysty);
            pictureBox1.Left = x;
            pictureBox1.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox2.Left = x;
            pictureBox2.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox3.Left = x;
            pictureBox3.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox4.Left = x;
            pictureBox4.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox5.Left = x;
            pictureBox5.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox6.Left = x;
            pictureBox6.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox7.Left = x;
            pictureBox7.Top = y;
            x = rand.Next(vasen);
            y = rand.Next(pysty);
            pictureBox8.Left = x;
            pictureBox8.Top = y;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }

        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }
        }

        private void pictureBox7_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }
        }

        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }
        }

        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }
        }

        private void pictureBox6_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }
        }

        private void pictureBox8_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                xx = e.X;
                yy = e.Y;
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox1.Left += (e.X - xx);
                pictureBox1.Top += (e.Y - yy);
            }

        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox2.Left += (e.X - xx);
                pictureBox2.Top += (e.Y - yy);
            }

        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox3.Left += (e.X - xx);
                pictureBox3.Top += (e.Y - yy);
            }

        }

        private void pictureBox7_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox7.Left += (e.X - xx);
                pictureBox7.Top += (e.Y - yy);
            }

        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox4.Left += (e.X - xx);
                pictureBox4.Top += (e.Y - yy);
            }

        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox5.Left += (e.X - xx);
                pictureBox5.Top += (e.Y - yy);
            }

        }

        private void pictureBox6_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox6.Left += (e.X - xx);
                pictureBox6.Top += (e.Y - yy);
            }

        }

        private void pictureBox8_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pictureBox8.Left += (e.X - xx);
                pictureBox8.Top += (e.Y - yy);
            }

        }
    }
}
