﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kristian_2021_Tentti
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string syntymapaiva = textBox1.Text;
            string ekaarvo = syntymapaiva.Substring(0, 1);
            string tokaarvo = syntymapaiva.Substring(1, 1);
            string kolmasarvo = syntymapaiva.Substring(3, 1);
            string neljasarvo = syntymapaiva.Substring(4, 1);
            string viidesarvo = syntymapaiva.Substring(6, 1);
            string kuudesarvo = syntymapaiva.Substring(7, 1);
            string seitsemasarvo = syntymapaiva.Substring(8, 1);
            string kahdekasarvo = syntymapaiva.Substring(9, 1);
            int ekaarvoint = Convert.ToInt16(ekaarvo);
            int tokaarvoint = Convert.ToInt16(tokaarvo);
            int kolmasarvoint = Convert.ToInt16(kolmasarvo);
            int neljasarvoint = Convert.ToInt16(neljasarvo);
            int viidesarvoint = Convert.ToInt16(viidesarvo);
            int kuudesarvoint = Convert.ToInt16(kuudesarvo);
            int seitsemasarvoint = Convert.ToInt16(seitsemasarvo);
            int kahdekasarvoint = Convert.ToInt16(kahdekasarvo);
            int arvotyhteensa = ekaarvoint + tokaarvoint + kolmasarvoint + neljasarvoint + viidesarvoint + kuudesarvoint + seitsemasarvoint + kahdekasarvoint;
            string ekatulo = Convert.ToString(arvotyhteensa);
            string ekatuloeka = ekatulo.Substring(0, 1);
            string ekatulotoka = ekatulo.Substring(1, 1);
            int ekatuloekaint = Convert.ToInt16(ekatuloeka);
            int ekatulotokaint = Convert.ToInt16(ekatulotoka);
            int tuloooo = ekatuloekaint + ekatulotokaint;
            string onnea1 = Convert.ToString(tuloooo);
            string onnea2 = onnea1.Substring(0, 1);
            string onnea3 = onnea1.Substring(1, 1);
            int laske1 = Convert.ToInt16(onnea2);
            int laske2 = Convert.ToInt16(onnea3);
            int onnenluku = laske1 + laske2;
            string vastaustehtava1 = Convert.ToString(onnenluku);
            onnennumero.Text = vastaustehtava1;






        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {


            string[,] joukkueet =
           {
            {"R", "Team","GP", "2", "5", "10"},
            {"1", "LAT", "6", "44", "1", "1"},
            {"2", "USA", "7", "30", "1", "0"},
            {"3", "SVK", "5", "24", "0","2"},
            {"4", "RUS", "7", "32", "0", "0"},
            {"5", "CAN", "7", "31", "0", "0"},
            {"6", "SWE", "7", "30", "0", "0"},
            {"7", "DEN", "5", "21", "0", "1"},
            {"8", "SUI", "5", "20", "0", "1"},
            {"9", "CZE", "5", "21", "0", "0"},
            { "9", "FIN", "6", "21", "0", "0" }};

            string haettava = textBox2.Text;
            for (int r = 0; r < 11; r++)
                if (joukkueet[r, 1] == haettava)
                {
                    joukkueenkahdenminuutinjaahyt.Text = joukkueet[r, 3];
                    joukkueennimi.Text = textBox2.Text;
                    break;


                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           


            
            
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }
    }
}
