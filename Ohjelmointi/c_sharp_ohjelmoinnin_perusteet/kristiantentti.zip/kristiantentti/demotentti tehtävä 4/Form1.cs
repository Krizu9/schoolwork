﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demotentti_tehtävä_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        Random rand = new Random();
        int A = 4;
        
        
        private void button1_Click(object sender, EventArgs e)
        {
           
            int heitto = rand.Next(1,7);
            string nayta = Convert.ToString(heitto);
            Tulos.Text = nayta;
            string axat = "";
            System.Windows.Forms.Label abc = new System.Windows.Forms.Label();
            this.Controls.Add(abc);
            abc.Top = A * 28;
            abc.Left = 15;
            
            if (heitto == 1)
            {
                axat = "x";
            }
            if (heitto == 2)
            {
                axat = "xx";
            }
            if (heitto == 3)
            {
                axat = "xxx";
            }
            if (heitto == 4)
            {
                axat = "xxxx";
            }
            if (heitto == 5)
            {
                axat = "xxxxx";
            }
            if (heitto == 6)
            {
                axat = "xxxxxx";
            }
            abc.Text = "Heitit:" + axat;


            A = A + 1;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            
        }
    }
}
