﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demotentti_tehtävä_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        
        double neliojuuri;
        double ylapuoli1;
        
        double alapuoli;
        double lopullinenvastaus1;
        double lopullinenvastaus2;
        double ylapuoli2;
        double diskriminantti;
       
        private void button1_Click(object sender, EventArgs e)
        {

            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            



            string a = textBox1.Text;
            double ax = Convert.ToDouble(a);
            string b = textBox2.Text;
            double bx = Convert.ToDouble(b);
            string c = textBox3.Text;
            double cx = Convert.ToDouble(c);

            diskriminantti = Math.Pow(bx, 2) - 4 * ax * cx;
            neliojuuri = Math.Sqrt (diskriminantti);
            if (neliojuuri >= 0)
            {
                ylapuoli1 = -bx - neliojuuri;
                ylapuoli2 = -bx + neliojuuri;
                alapuoli = 2 * ax;
                lopullinenvastaus1 = ylapuoli1 / alapuoli;
                lopullinenvastaus2 = ylapuoli2 / alapuoli;
                string tulostettava1 = Convert.ToString(lopullinenvastaus1);
                string tulostettava2 = Convert.ToString(lopullinenvastaus2);
                string disk = Convert.ToString(diskriminantti);
                label5.Text = tulostettava1;
                label6.Text = tulostettava2;
                label7.Text = disk;
            }
            else
            {
                label5.Text = "arvoistasi ei voi ottaa neliöjuurta";
                label6.Text = "arvoistasi ei voi ottaa neliöjuurta";

            }
            
            


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
