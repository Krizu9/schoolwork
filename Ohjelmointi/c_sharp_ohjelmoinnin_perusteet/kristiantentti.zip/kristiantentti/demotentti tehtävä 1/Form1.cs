﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demotentti
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[,] opiskelijat =
            {
            {"Kai", "22" },
            {"Eki", "12" },
            {"Tea", "9" },
            {"Lea", "16" },
            {"Pia", "20" } };
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string haettava = textBox1.Text;
            for (int r = 0; r < 5; r++)
                if (opiskelijat[r, 0] == haettava)
                {
                    label1.Text =  opiskelijat[r, 1];
                    label2.Text = textBox1.Text;
                    break;
                }


        }
    }
}
