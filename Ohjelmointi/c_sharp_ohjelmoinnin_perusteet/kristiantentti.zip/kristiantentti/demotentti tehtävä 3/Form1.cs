﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demotentti_tehtävä_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
         

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            sika.Visible = false;
            biisoni.Visible = false;
            lintu.Visible = false;
            mato.Visible = true;
            rotta.Visible = false;
        }

        private void rotta_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            sika.Visible = true;
            biisoni.Visible = false;
            lintu.Visible = false;
            mato.Visible = false;
            rotta.Visible = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            sika.Visible = false;
            biisoni.Visible = false;
            lintu.Visible = true;
            mato.Visible = false;
            rotta.Visible = false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sika.Visible = false;
            biisoni.Visible = true;
            lintu.Visible = false;
            mato.Visible = false;
            rotta.Visible = false;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            sika.Visible = false;
            biisoni.Visible = false;
            lintu.Visible = false;
            mato.Visible = false;
            rotta.Visible = true;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            sika.Visible = false;
            biisoni.Visible = false;
            lintu.Visible = false;
            mato.Visible = false;
            rotta.Visible = false;
        }
    }
}
