﻿namespace demotentti_tehtävä_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.lintu = new System.Windows.Forms.PictureBox();
            this.mato = new System.Windows.Forms.PictureBox();
            this.rotta = new System.Windows.Forms.PictureBox();
            this.biisoni = new System.Windows.Forms.PictureBox();
            this.sika = new System.Windows.Forms.PictureBox();
            this.tyhja = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.lintu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rotta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.biisoni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sika)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(40, 162);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(46, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "Sika";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(40, 185);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(49, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Mato";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(40, 208);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(48, 17);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Tag = "";
            this.radioButton3.Text = "Lintu";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(40, 231);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(55, 17);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Biisoni";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(40, 254);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(51, 17);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Rotta";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // lintu
            // 
            this.lintu.Image = ((System.Drawing.Image)(resources.GetObject("lintu.Image")));
            this.lintu.Location = new System.Drawing.Point(234, 100);
            this.lintu.Name = "lintu";
            this.lintu.Size = new System.Drawing.Size(379, 227);
            this.lintu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lintu.TabIndex = 5;
            this.lintu.TabStop = false;
            this.lintu.Visible = false;
            // 
            // mato
            // 
            this.mato.Image = ((System.Drawing.Image)(resources.GetObject("mato.Image")));
            this.mato.Location = new System.Drawing.Point(234, 100);
            this.mato.Name = "mato";
            this.mato.Size = new System.Drawing.Size(379, 227);
            this.mato.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mato.TabIndex = 6;
            this.mato.TabStop = false;
            this.mato.Visible = false;
            // 
            // rotta
            // 
            this.rotta.Image = ((System.Drawing.Image)(resources.GetObject("rotta.Image")));
            this.rotta.Location = new System.Drawing.Point(234, 100);
            this.rotta.Name = "rotta";
            this.rotta.Size = new System.Drawing.Size(379, 227);
            this.rotta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rotta.TabIndex = 7;
            this.rotta.TabStop = false;
            this.rotta.Visible = false;
            this.rotta.Click += new System.EventHandler(this.rotta_Click);
            // 
            // biisoni
            // 
            this.biisoni.Image = ((System.Drawing.Image)(resources.GetObject("biisoni.Image")));
            this.biisoni.Location = new System.Drawing.Point(234, 100);
            this.biisoni.Name = "biisoni";
            this.biisoni.Size = new System.Drawing.Size(379, 227);
            this.biisoni.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.biisoni.TabIndex = 8;
            this.biisoni.TabStop = false;
            this.biisoni.Visible = false;
            // 
            // sika
            // 
            this.sika.Image = ((System.Drawing.Image)(resources.GetObject("sika.Image")));
            this.sika.Location = new System.Drawing.Point(234, 100);
            this.sika.Name = "sika";
            this.sika.Size = new System.Drawing.Size(379, 227);
            this.sika.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sika.TabIndex = 9;
            this.sika.TabStop = false;
            this.sika.Visible = false;
            // 
            // tyhja
            // 
            this.tyhja.AutoSize = true;
            this.tyhja.Location = new System.Drawing.Point(40, 139);
            this.tyhja.Name = "tyhja";
            this.tyhja.Size = new System.Drawing.Size(103, 17);
            this.tyhja.TabIndex = 10;
            this.tyhja.TabStop = true;
            this.tyhja.Text = "Älä näytä eläintä";
            this.tyhja.UseVisualStyleBackColor = true;
            this.tyhja.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tyhja);
            this.Controls.Add(this.sika);
            this.Controls.Add(this.biisoni);
            this.Controls.Add(this.rotta);
            this.Controls.Add(this.mato);
            this.Controls.Add(this.lintu);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.lintu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rotta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.biisoni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sika)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.PictureBox lintu;
        private System.Windows.Forms.PictureBox mato;
        private System.Windows.Forms.PictureBox rotta;
        private System.Windows.Forms.PictureBox biisoni;
        private System.Windows.Forms.PictureBox sika;
        private System.Windows.Forms.RadioButton tyhja;
    }
}

