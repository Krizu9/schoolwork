﻿namespace tasohyppelypeli
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pelaaja = new System.Windows.Forms.PictureBox();
            this.txtpisteet = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.liikkuvayksi = new System.Windows.Forms.PictureBox();
            this.maali = new System.Windows.Forms.PictureBox();
            this.liikkuvakaksi = new System.Windows.Forms.PictureBox();
            this.liikkuvakolme = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.peliajastin = new System.Windows.Forms.Timer(this.components);
            this.vihollinenkaksi = new System.Windows.Forms.PictureBox();
            this.vihollinenkolme = new System.Windows.Forms.PictureBox();
            this.vihollinenyksi = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pelaaja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.liikkuvayksi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maali)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.liikkuvakaksi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.liikkuvakolme)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vihollinenkaksi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vihollinenkolme)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vihollinenyksi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 606);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1342, 28);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "taso";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(171, 550);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(198, 20);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "taso";
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pelaaja
            // 
            this.pelaaja.BackColor = System.Drawing.Color.Transparent;
            this.pelaaja.Image = ((System.Drawing.Image)(resources.GetObject("pelaaja.Image")));
            this.pelaaja.Location = new System.Drawing.Point(12, 560);
            this.pelaaja.Name = "pelaaja";
            this.pelaaja.Size = new System.Drawing.Size(51, 40);
            this.pelaaja.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pelaaja.TabIndex = 2;
            this.pelaaja.TabStop = false;
            this.pelaaja.Click += new System.EventHandler(this.pelaaja_Click);
            // 
            // txtpisteet
            // 
            this.txtpisteet.BackColor = System.Drawing.Color.Transparent;
            this.txtpisteet.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpisteet.Location = new System.Drawing.Point(1148, 9);
            this.txtpisteet.Name = "txtpisteet";
            this.txtpisteet.Size = new System.Drawing.Size(181, 177);
            this.txtpisteet.TabIndex = 3;
            this.txtpisteet.Text = "Pisteet";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Location = new System.Drawing.Point(620, 327);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(198, 20);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "taso";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.Location = new System.Drawing.Point(321, 477);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(198, 20);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Tag = "taso";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.Location = new System.Drawing.Point(104, 256);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(198, 20);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "taso";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.Location = new System.Drawing.Point(357, 93);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(198, 20);
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "taso";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.Location = new System.Drawing.Point(1131, 447);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(198, 20);
            this.pictureBox9.TabIndex = 9;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "taso";
            // 
            // liikkuvayksi
            // 
            this.liikkuvayksi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("liikkuvayksi.BackgroundImage")));
            this.liikkuvayksi.Location = new System.Drawing.Point(336, 197);
            this.liikkuvayksi.Name = "liikkuvayksi";
            this.liikkuvayksi.Size = new System.Drawing.Size(74, 20);
            this.liikkuvayksi.TabIndex = 10;
            this.liikkuvayksi.TabStop = false;
            this.liikkuvayksi.Tag = "taso";
            // 
            // maali
            // 
            this.maali.Image = ((System.Drawing.Image)(resources.GetObject("maali.Image")));
            this.maali.Location = new System.Drawing.Point(1131, 361);
            this.maali.Name = "maali";
            this.maali.Size = new System.Drawing.Size(198, 92);
            this.maali.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.maali.TabIndex = 11;
            this.maali.TabStop = false;
            // 
            // liikkuvakaksi
            // 
            this.liikkuvakaksi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("liikkuvakaksi.BackgroundImage")));
            this.liikkuvakaksi.Location = new System.Drawing.Point(879, 391);
            this.liikkuvakaksi.Name = "liikkuvakaksi";
            this.liikkuvakaksi.Size = new System.Drawing.Size(74, 20);
            this.liikkuvakaksi.TabIndex = 12;
            this.liikkuvakaksi.TabStop = false;
            this.liikkuvakaksi.Tag = "taso";
            // 
            // liikkuvakolme
            // 
            this.liikkuvakolme.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("liikkuvakolme.BackgroundImage")));
            this.liikkuvakolme.Location = new System.Drawing.Point(992, 438);
            this.liikkuvakolme.Name = "liikkuvakolme";
            this.liikkuvakolme.Size = new System.Drawing.Size(74, 20);
            this.liikkuvakolme.TabIndex = 13;
            this.liikkuvakolme.TabStop = false;
            this.liikkuvakolme.Tag = "taso";
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox12.BackgroundImage")));
            this.pictureBox12.Location = new System.Drawing.Point(228, 197);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(74, 20);
            this.pictureBox12.TabIndex = 14;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "taso";
            // 
            // peliajastin
            // 
            this.peliajastin.Enabled = true;
            this.peliajastin.Interval = 1;
            this.peliajastin.Tick += new System.EventHandler(this.Paapeliajastin);
            // 
            // vihollinenkaksi
            // 
            this.vihollinenkaksi.BackColor = System.Drawing.Color.Transparent;
            this.vihollinenkaksi.Image = ((System.Drawing.Image)(resources.GetObject("vihollinenkaksi.Image")));
            this.vihollinenkaksi.Location = new System.Drawing.Point(488, 438);
            this.vihollinenkaksi.Name = "vihollinenkaksi";
            this.vihollinenkaksi.Size = new System.Drawing.Size(31, 41);
            this.vihollinenkaksi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.vihollinenkaksi.TabIndex = 15;
            this.vihollinenkaksi.TabStop = false;
            this.vihollinenkaksi.Tag = "vihollinen";
            // 
            // vihollinenkolme
            // 
            this.vihollinenkolme.BackColor = System.Drawing.Color.Transparent;
            this.vihollinenkolme.Image = ((System.Drawing.Image)(resources.GetObject("vihollinenkolme.Image")));
            this.vihollinenkolme.Location = new System.Drawing.Point(620, 290);
            this.vihollinenkolme.Name = "vihollinenkolme";
            this.vihollinenkolme.Size = new System.Drawing.Size(31, 41);
            this.vihollinenkolme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.vihollinenkolme.TabIndex = 16;
            this.vihollinenkolme.TabStop = false;
            this.vihollinenkolme.Tag = "vihollinen";
            // 
            // vihollinenyksi
            // 
            this.vihollinenyksi.BackColor = System.Drawing.Color.Transparent;
            this.vihollinenyksi.Image = ((System.Drawing.Image)(resources.GetObject("vihollinenyksi.Image")));
            this.vihollinenyksi.Location = new System.Drawing.Point(271, 510);
            this.vihollinenyksi.Name = "vihollinenyksi";
            this.vihollinenyksi.Size = new System.Drawing.Size(31, 41);
            this.vihollinenyksi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.vihollinenyksi.TabIndex = 17;
            this.vihollinenyksi.TabStop = false;
            this.vihollinenyksi.Tag = "vihollinen";
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(182, 514);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(33, 37);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 18;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Tag = "tahti";
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(114, 222);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(33, 37);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 19;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Tag = "tahti";
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(171, 222);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(33, 37);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 20;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Tag = "tahti";
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(378, 59);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(33, 37);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 21;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Tag = "tahti";
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(444, 59);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(33, 37);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 22;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Tag = "tahti";
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(898, 167);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(33, 37);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 23;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Tag = "tahti";
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox18.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox18.Image")));
            this.pictureBox18.Location = new System.Drawing.Point(657, 294);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(33, 37);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 24;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Tag = "tahti";
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox19.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox19.Image")));
            this.pictureBox19.Location = new System.Drawing.Point(1008, 26);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(33, 37);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 25;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Tag = "tahti";
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox20.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox20.Image")));
            this.pictureBox20.Location = new System.Drawing.Point(336, 271);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(33, 37);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 26;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Tag = "tahti";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1296, 563);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 27;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "tahti";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-5, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 24);
            this.label1.TabIndex = 28;
            this.label1.Text = "Space = Hyppy";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-5, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(294, 24);
            this.label2.TabIndex = 29;
            this.label2.Text = "Vasen nuoli = Liikkuu vasemmalle";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-5, 361);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 24);
            this.label3.TabIndex = 30;
            this.label3.Text = "Oikea nuoli = Liikkuu vasemmalle";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-5, 395);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(272, 24);
            this.label4.TabIndex = 31;
            this.label4.Text = "Enter = Aloittaa pelin uudelleen";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1341, 646);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.vihollinenyksi);
            this.Controls.Add(this.vihollinenkolme);
            this.Controls.Add(this.vihollinenkaksi);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.liikkuvakolme);
            this.Controls.Add(this.liikkuvakaksi);
            this.Controls.Add(this.maali);
            this.Controls.Add(this.liikkuvayksi);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.txtpisteet);
            this.Controls.Add(this.pelaaja);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pelaaja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.liikkuvayksi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maali)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.liikkuvakaksi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.liikkuvakolme)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vihollinenkaksi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vihollinenkolme)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vihollinenyksi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pelaaja;
        private System.Windows.Forms.Label txtpisteet;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox liikkuvayksi;
        private System.Windows.Forms.PictureBox maali;
        private System.Windows.Forms.PictureBox liikkuvakaksi;
        private System.Windows.Forms.PictureBox liikkuvakolme;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Timer peliajastin;
        private System.Windows.Forms.PictureBox vihollinenkaksi;
        private System.Windows.Forms.PictureBox vihollinenkolme;
        private System.Windows.Forms.PictureBox vihollinenyksi;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

